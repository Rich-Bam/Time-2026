-- Quick check: Does the users_public view exist?
SELECT * FROM users_public LIMIT 1;








